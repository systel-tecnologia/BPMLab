/*
	File  : StorageDevice.h
	Version : 1.0
	Date  : 05/03/2019
	Project : Systel Equino Storange Device Driver Interface
	Author  : Daniel Valentin - dtvalentin@gmail.com
	
*/

#ifndef _StorageDevice_H_
	#define _StorageDevice_H_
	
	class StorageDevice {
		// user-accessible "public" interface
		public:
		
		void read(uint8_t* data, uint8_t size, uint8_t address);
	
		void write(uint8_t address, uint8_t data);
	
		void write(uint8_t address, uint8_t* data, uint8_t size);
	
		// library-accessible "protected" interface
		protected:
		
		// library-accessible "private" interface
		private:
	};
		
#endif