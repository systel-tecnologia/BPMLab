/*
	File  : DataReceiverDevice.h
	Version : 1.0
	Date  : 05/03/2019
	Project : Systel Equino Data Receiver Device Driver Interface
	Author  : Daniel Valentin - dtvalentin@gmail.com
	
*/

#ifndef _DataReceiverDevice_H_
	#define _DataReceiverDevice_H_
	
	#include "Equino.h"
	
	// library interface description
	class DataReceiverDevice {
		// user-accessible "public" interface
		public:
				
		// library-accessible "protected" interface
		protected:
		
		// library-accessible "private" interface
		private:
		
	};

#endif